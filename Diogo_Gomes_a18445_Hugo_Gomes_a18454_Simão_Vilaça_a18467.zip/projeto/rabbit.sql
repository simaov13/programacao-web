-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 24-Jun-2020 às 00:00
-- Versão do servidor: 10.4.11-MariaDB
-- versão do PHP: 7.4.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `rabbit`
--
CREATE DATABASE IF NOT EXISTS `rabbit` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `rabbit`;

-- --------------------------------------------------------

--
-- Estrutura da tabela `comments`
--

CREATE TABLE `comments` (
  `id_comment` int(11) NOT NULL,
  `id_post` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `text` varchar(10000) NOT NULL,
  `score` int(11) NOT NULL DEFAULT 0,
  `date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `comments`
--

INSERT INTO `comments` (`id_comment`, `id_post`, `id_user`, `text`, `score`, `date`) VALUES
(1, 1, 4, 'Sed eleifend semper vehicula. Praesent interdum euismod neque ut tempor. Sed at aliquam nisi. In ut lobortis dui. Aliquam erat volutpat. Sed sit amet nulla in dui venenatis tincidunt. Nullam urna diam, rutrum vel lobortis eu, lobortis et mi. Pellentesque vitae porta ligula. Praesent ullamcorper tortor quis nisl pharetra porta.', 0, '2020-06-16 19:18:08'),
(2, 2, 5, 'Sed eleifend semper vehicula. Praesent interdum euismod neque ut tempor. Sed at aliquam nisi. In ut lobortis dui. Aliquam erat volutpat. Sed sit amet nulla in dui venenatis tincidunt. Nullam urna diam, rutrum vel lobortis eu, lobortis et mi. Pellentesque vitae porta ligula. Praesent ullamcorper tortor quis nisl pharetra porta.', 0, '2020-06-19 13:45:56');

-- --------------------------------------------------------

--
-- Estrutura da tabela `comments_votes`
--

CREATE TABLE `comments_votes` (
  `id_comment_vote` int(11) NOT NULL,
  `id_comment` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `vote` enum('up','down') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `posts`
--

CREATE TABLE `posts` (
  `id_post` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `text` varchar(10000) NOT NULL,
  `score` int(11) NOT NULL DEFAULT 0,
  `date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `posts`
--

INSERT INTO `posts` (`id_post`, `id_user`, `text`, `score`, `date`) VALUES
(1, 3, 'Morbi mauris nunc, consequat a lectus bibendum, gravida convallis tortor. In pharetra lacus vitae ultrices elementum. Nam id volutpat erat. Interdum et malesuada fames ac ante ipsum primis in faucibus. Pellentesque sit amet risus molestie arcu convallis tincidunt finibus ut elit. Maecenas scelerisque condimentum augue. Aenean ac ornare ligula, vitae vehicula justo. Etiam felis ex, consectetur eu dui sed, consequat sodales ipsum. Aenean venenatis nisi non enim consectetur vestibulum.', 17, '2020-06-14 18:42:31'),
(2, 4, 'In dui purus, mattis id interdum sit amet, volutpat ac eros. Suspendisse consectetur faucibus ante hendrerit porta. Nullam cursus nibh at nibh dignissim vestibulum. Aliquam erat volutpat. Phasellus non libero vel velit semper aliquet vel quis arcu. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam rutrum magna a elit pellentesque, a blandit quam ultricies. Quisque cursus euismod turpis quis dignissim. In pellentesque est in sem lobortis, ut ultrices turpis dignissim. Fusce faucibus consectetur velit et molestie. Aliquam tincidunt, tortor vitae eleifend facilisis, libero nisi dapibus nisl, finibus accumsan eros est vitae eros.', 13, '2020-06-14 23:14:12'),
(3, 5, 'Sed condimentum accumsan massa, at rhoncus urna fringilla sed. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec sed est egestas, cursus quam in, commodo lorem. Ut interdum aliquet dolor, quis vestibulum metus aliquet maximus. Donec commodo nisi id tincidunt lobortis. Ut feugiat mi at elementum volutpat. Pellentesque metus odio, venenatis sed ligula fermentum, tempor tempor tellus.', 0, '2020-06-19 14:14:24');

-- --------------------------------------------------------

--
-- Estrutura da tabela `posts_votes`
--

CREATE TABLE `posts_votes` (
  `id_post_vote` int(11) NOT NULL,
  `id_post` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `vote` enum('up','down') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `users`
--

CREATE TABLE `users` (
  `id_user` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(100) NOT NULL,
  `activation_code` varchar(50) NOT NULL DEFAULT '',
  `rememberme` varchar(255) NOT NULL DEFAULT '',
  `reset` varchar(50) DEFAULT '',
  `since` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `users`
--

INSERT INTO `users` (`id_user`, `username`, `password`, `email`, `activation_code`, `rememberme`, `reset`, `since`) VALUES
(1, 'admin', '$2y$10$ZU7Jq5yZ1U/ifeJoJzvLbenjRyJVkSzmQKQc.X0KDPkfR3qs/iA7O', 'admin@example.com', 'activated', '$2y$10$thbuql5yGt23pk5SjsginOutYOT1k4pfES2/x87megtlOnXQ5kG16', '', '2020-06-09 23:00:00'),
(2, 'member', '$2y$10$7vKi0TjZimZyp/S5aCtK0eLsGagyIJVfpzGSFgRSqDGkJMxqoIYV.', 'member@example.com', 'activated', '', '', '2020-06-10 00:01:01'),
(3, 'diogopsgomes', '$2y$10$HSEg0xSq6sxvFK5N3.Kt1O/CRsAzvIZe5DXFZVotR209EcXOyE35.', 'diogopsgomes@gmail.com', 'activated', '$2y$10$fJYgIUm74JfyDCELbnUype.CkvVI9/085R2oSzEfkboGzsnZsqbW6', '', '2020-06-17 12:37:00'),
(4, 'simaov.13', '$2y$10$KXrxHKPjN/luZrnPOIM84.8OuczPTHnKLolDRPdM7YPR25oRkG2Qa', 'simaospam13@gmail.com', 'activated', '$2y$10$SdAe25PW1O3JLRO61QF3bOcHeZDDxQNRjFDWHzsu4Y.MBvvk0czzu', '', '2020-06-13 12:13:13'),
(5, 'hugogomes999', '$2y$10$mLIRq6EIs5SKa4q7bcBnOedsWvsNShdMDTrNb2N5ODONwtKCenl0K', 'hugogomes999@sapo.pt', 'activated', '', '', '2020-06-27 02:27:27');

--
-- Índices para tabelas despejadas
--

--
-- Índices para tabela `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`id_comment`),
  ADD KEY `id_post` (`id_post`),
  ADD KEY `id_user` (`id_user`);

--
-- Índices para tabela `comments_votes`
--
ALTER TABLE `comments_votes`
  ADD PRIMARY KEY (`id_comment_vote`),
  ADD KEY `id_comment` (`id_comment`,`id_user`),
  ADD KEY `id_user` (`id_user`);

--
-- Índices para tabela `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`id_post`),
  ADD KEY `id_user` (`id_user`);

--
-- Índices para tabela `posts_votes`
--
ALTER TABLE `posts_votes`
  ADD PRIMARY KEY (`id_post_vote`),
  ADD KEY `id_post` (`id_post`),
  ADD KEY `id_user` (`id_user`);

--
-- Índices para tabela `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id_user`);

--
-- AUTO_INCREMENT de tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `comments`
--
ALTER TABLE `comments`
  MODIFY `id_comment` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de tabela `comments_votes`
--
ALTER TABLE `comments_votes`
  MODIFY `id_comment_vote` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `posts`
--
ALTER TABLE `posts`
  MODIFY `id_post` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de tabela `posts_votes`
--
ALTER TABLE `posts_votes`
  MODIFY `id_post_vote` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `users`
--
ALTER TABLE `users`
  MODIFY `id_user` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Restrições para despejos de tabelas
--

--
-- Limitadores para a tabela `comments`
--
ALTER TABLE `comments`
  ADD CONSTRAINT `comments_ibfk_1` FOREIGN KEY (`id_post`) REFERENCES `posts` (`id_post`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `comments_ibfk_2` FOREIGN KEY (`id_user`) REFERENCES `users` (`id_user`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Limitadores para a tabela `comments_votes`
--
ALTER TABLE `comments_votes`
  ADD CONSTRAINT `comments_votes_ibfk_1` FOREIGN KEY (`id_user`) REFERENCES `users` (`id_user`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `comments_votes_ibfk_2` FOREIGN KEY (`id_comment`) REFERENCES `comments` (`id_comment`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Limitadores para a tabela `posts`
--
ALTER TABLE `posts`
  ADD CONSTRAINT `posts_ibfk_1` FOREIGN KEY (`id_user`) REFERENCES `users` (`id_user`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Limitadores para a tabela `posts_votes`
--
ALTER TABLE `posts_votes`
  ADD CONSTRAINT `posts_votes_ibfk_1` FOREIGN KEY (`id_post`) REFERENCES `posts` (`id_post`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `posts_votes_ibfk_2` FOREIGN KEY (`id_user`) REFERENCES `users` (`id_user`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
