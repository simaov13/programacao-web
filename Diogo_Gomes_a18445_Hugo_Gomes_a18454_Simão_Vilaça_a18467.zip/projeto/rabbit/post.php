<?php
	require 'include/main.php';
	check_rememberme_cookie($con);

    if (isset($_GET['id']) && !empty($_GET['id'])) {
        $stmt = $con->prepare('SELECT id_post, posts.id_user, users.username, text, score, date FROM posts INNER JOIN users ON posts.id_user = users.id_user WHERE id_post = ?');
        $stmt->bind_param('i', $_GET['id']);
        $stmt->execute();
        $stmt->store_result();

        if ($stmt->num_rows > 0) {
            $stmt->bind_result($id_post, $id_user, $username, $text, $score, $date);
            $stmt->fetch();
            $stmt->close();

            $date = date("d/m/Y H:i", strtotime($date));
            $edit = false;

            if (isset($_POST['newcomment']) && !empty($_POST['newcomment'])) {
                $stmt = $con->prepare('INSERT INTO comments (id_post, id_user, text) VALUES (?, ?, ?)');
                $stmt->bind_param('iis', $_GET['id'], $_SESSION['id'], $_POST['newcomment']);
                $stmt->execute();
                $stmt->close();
        
                header('Location: post?id=' . $_GET['id']);
                exit;
            }

            if (isset($_POST['editpost']) && !empty($_POST['editpost']) && $id_user == $_SESSION['id']) {
                $stmt = $con->prepare('UPDATE posts SET text = ? WHERE id_post = ?');
                $stmt->bind_param('si', $_POST['editpost'], $_GET['id']);
                $stmt->execute();
                $stmt->close();
        
                header('Location: post?id=' . $_GET['id']);
                exit;
            }

            if (isset($_GET['action']) && !empty($_GET['action']) && $id_user == $_SESSION['id']) {
                if ($_GET['action'] == 'delete') {
                    $stmt = $con->prepare('DELETE FROM posts WHERE id_post = ?');
                    $stmt->bind_param('i', $_GET['id']);
                    $stmt->execute();
                    $stmt->close();
            
                    header('Location: index');
                    exit;
                }
                
                if ($_GET['action'] == 'edit') {
                    $edit = true;
                }
            }

        } else {
            header('Location: index');
            exit;
        }

    } else {
        header('Location: index');
        exit;
    }

    $title = $text;
?>
<!DOCTYPE html>
<html lang="pt">
	<?php require 'include/head.php'?>
	<body>
		<?php require 'include/header.php'?>
		<main class="white">
            <p class="infomsg">Post #<?=$id_post?></p>
            <article id="post-<?=$id_post?>">
                <div class="vote">
                    <a href="#" class="upvote">
                        <svg x="0px" y="0px" viewBox="0 0 512.171 512.171" width="16px" height="16px">
                            <g>
                                <path d="M476.723,216.64L263.305,3.115C261.299,1.109,258.59,0,255.753,0c-2.837,0-5.547,1.131-7.552,3.136L35.422,216.64    c-3.051,3.051-3.947,7.637-2.304,11.627c1.664,3.989,5.547,6.571,9.856,6.571h117.333v266.667c0,5.888,4.779,10.667,10.667,10.667    h170.667c5.888,0,10.667-4.779,10.667-10.667V234.837h116.885c4.309,0,8.192-2.603,9.856-6.592    C480.713,224.256,479.774,219.691,476.723,216.64z" data-original="#000000" class="active-path" data-old_color="#000000" fill="#cbcbcb"/>
                            </g>
                        </svg>
                    </a>
                    <p class="score caption"><?=$score?></p>
                    <a href="#" class="downvote">
                        <svg x="0px" y="0px" viewBox="0 0 512.171 512.171" width="16px" height="16px">
                            <g>
                                <path d="M479.046,283.925c-1.664-3.989-5.547-6.592-9.856-6.592H352.305V10.667C352.305,4.779,347.526,0,341.638,0H170.971    c-5.888,0-10.667,4.779-10.667,10.667v266.667H42.971c-4.309,0-8.192,2.603-9.856,6.571c-1.643,3.989-0.747,8.576,2.304,11.627    l212.8,213.504c2.005,2.005,4.715,3.136,7.552,3.136s5.547-1.131,7.552-3.115l213.419-213.504    C479.793,292.501,480.71,287.915,479.046,283.925z" data-original="#000000" class="active-path" data-old_color="#000000" fill="#cbcbcb"/>
                            </g>
                        </svg>
                    </a>
                </div>
                <div class="content">
                    <div class="info">
                        <div class="user-container">
                            <img src="img/user.svg" alt="User">
                            <a href="profile?u=<?=$username?>" class="user caption"><?=$username?></a>
                        </div>
                        <div class="date-container">
                            <span class="date caption thin"> · <?=$date?></span>
                        </div>
                    </div>
                    <?php if (!$edit) { ?>
                    <div class="text"><?=$text?></div>
                    <?php } else { ?>
                    <form action="post?id=<?=$id_post?>" method="POST" class="edit-form">
                        <textarea name="editpost" required autofocus><?=$text?></textarea>
                    </form>
                    <?php } ?>
                </div>
                <?php if (isset($_SESSION['loggedin']) && $id_user == $_SESSION['id']) { ?>
                <div class="actions">
                    <?php if (!$edit) { ?>
                    <a href="post?id=<?=$id_post?>&action=edit" class="edit">
                        <svg x="0px" y="0px" viewBox="0 0 477.873 477.873" width="24px" height="24px">
                            <g>
                                <path d="M392.533,238.937c-9.426,0-17.067,7.641-17.067,17.067V426.67c0,9.426-7.641,17.067-17.067,17.067H51.2    c-9.426,0-17.067-7.641-17.067-17.067V85.337c0-9.426,7.641-17.067,17.067-17.067H256c9.426,0,17.067-7.641,17.067-17.067    S265.426,34.137,256,34.137H51.2C22.923,34.137,0,57.06,0,85.337V426.67c0,28.277,22.923,51.2,51.2,51.2h307.2    c28.277,0,51.2-22.923,51.2-51.2V256.003C409.6,246.578,401.959,238.937,392.533,238.937z" data-original="#000000" class="active-path" data-old_color="#000000" fill="#333333"/>
                            </g>
                            <g>
                                <path d="M458.742,19.142c-12.254-12.256-28.875-19.14-46.206-19.138c-17.341-0.05-33.979,6.846-46.199,19.149L141.534,243.937    c-1.865,1.879-3.272,4.163-4.113,6.673l-34.133,102.4c-2.979,8.943,1.856,18.607,10.799,21.585    c1.735,0.578,3.552,0.873,5.38,0.875c1.832-0.003,3.653-0.297,5.393-0.87l102.4-34.133c2.515-0.84,4.8-2.254,6.673-4.13    l224.802-224.802C484.25,86.023,484.253,44.657,458.742,19.142z M434.603,87.419L212.736,309.286l-66.287,22.135l22.067-66.202    L390.468,43.353c12.202-12.178,31.967-12.158,44.145,0.044c5.817,5.829,9.095,13.72,9.12,21.955    C443.754,73.631,440.467,81.575,434.603,87.419z" data-original="#000000" class="active-path" data-old_color="#000000" fill="#333333"/>
                            </g>
                        </svg>
                    </a>
                    <?php } else { ?>
                    <a href="#" class="edit-confirm">
                        <svg x="0px" y="0px" viewBox="0 0 426.667 426.667" width="24px" height="24px">
                            <g>
                                <path d="M421.876,56.307c-6.548-6.78-17.352-6.968-24.132-0.42c-0.142,0.137-0.282,0.277-0.42,0.42L119.257,334.375    l-90.334-90.334c-6.78-6.548-17.584-6.36-24.132,0.42c-6.388,6.614-6.388,17.099,0,23.713l102.4,102.4    c6.665,6.663,17.468,6.663,24.132,0L421.456,80.44C428.236,73.891,428.424,63.087,421.876,56.307z" data-original="#000000" class="active-path" data-old_color="#000000" fill="#333333"/>
                            </g>
                        </svg>
                    </a>
                    <?php } ?>
                    <a href="post?id=<?=$id_post?>&action=delete" class="delete">
                        <svg viewBox="0 0 512 512" width="24px" height="24px">
                            <g>
                                <path d="m424 64h-88v-16c0-26.467-21.533-48-48-48h-64c-26.467 0-48 21.533-48 48v16h-88c-22.056 0-40 17.944-40 40v56c0 8.836 7.164 16 16 16h8.744l13.823 290.283c1.221 25.636 22.281 45.717 47.945 45.717h242.976c25.665 0 46.725-20.081 47.945-45.717l13.823-290.283h8.744c8.836 0 16-7.164 16-16v-56c0-22.056-17.944-40-40-40zm-216-16c0-8.822 7.178-16 16-16h64c8.822 0 16 7.178 16 16v16h-96zm-128 56c0-4.411 3.589-8 8-8h336c4.411 0 8 3.589 8 8v40c-4.931 0-331.567 0-352 0zm313.469 360.761c-.407 8.545-7.427 15.239-15.981 15.239h-242.976c-8.555 0-15.575-6.694-15.981-15.239l-13.751-288.761h302.44z" data-original="#000000" class="active-path" data-old_color="#000000" fill="#333333"/>
                                <path d="m256 448c8.836 0 16-7.164 16-16v-208c0-8.836-7.164-16-16-16s-16 7.164-16 16v208c0 8.836 7.163 16 16 16z" data-original="#000000" class="active-path" data-old_color="#000000" fill="#333333"/>
                                <path d="m336 448c8.836 0 16-7.164 16-16v-208c0-8.836-7.164-16-16-16s-16 7.164-16 16v208c0 8.836 7.163 16 16 16z" data-original="#000000" class="active-path" data-old_color="#000000" fill="#333333"/>
                                <path d="m176 448c8.836 0 16-7.164 16-16v-208c0-8.836-7.164-16-16-16s-16 7.164-16 16v208c0 8.836 7.163 16 16 16z" data-original="#000000" class="active-path" data-old_color="#000000" fill="#333333"/>
                            </g>
                        </svg>
                    </a>
                </div>
                <?php } ?>
            </article>
            <section class="comments">
                <?php require 'include/newcomment.php'?>
                <?php require 'include/comments.php'?>
            </section>
		</main>
	</body>
</html>