<?php
require 'include/main.php';
$title = "Reenviar Email de Ativação";
// Output message
$msg = '';
// Check if the email from the resend activation form was submitted, isset() will check if the email exists.
if (isset($_POST['email'])) {
    // Prepare our SQL, preparing the SQL statement will prevent SQL injection.
    $stmt = $con->prepare('SELECT activation_code FROM users WHERE email = ? AND activation_code != "" AND activation_code != "activated"');
    // In this case we can use the account ID to get the account info.
    $stmt->bind_param('s', $_POST['email']);
    $stmt->execute();
    $stmt->store_result();
    // Check if the account exists:
    if ($stmt->num_rows > 0) {
        // Account exists
        $stmt->bind_result($activation_code);
        $stmt->fetch();
        // Account exist, the $msg variable will be used to show the output message (on the HTML form)
        send_activation_email($_POST['email'], $activation_code);
        $msg = 'O link de ativação foi enviado para o seu email!';
    } else {
        $msg = 'Não existe nenhuma conta para ser ativada com esse email!';
    }
    $stmt->close();
}
?>
<!DOCTYPE html>
<html>
    <?php require 'include/head.php'?>
	<body>
        <div class="center">
            <div class="center-container">
                <a href="index"><img src="img/rabbit.svg" alt="Logo"></a>
                <div class="center-box">
                    <p class="h4">Reenviar Email de Ativação</p>
                    <form action="resendactivation" method="POST">
                        <div class="input-container">
                            <input type="text" name="email" placeholder="Email" required autofocus>
                        </div>
                        <div class="alertmsg caption"><?=$msg?></div>
                        <input type="submit" value="Enviar" class="btn btn-outline caption">
                    </form>
                </div>
                <a href="index" class="h6">Voltar à página inicial</a>
            </div>
        </div>
	</body>
</html>
