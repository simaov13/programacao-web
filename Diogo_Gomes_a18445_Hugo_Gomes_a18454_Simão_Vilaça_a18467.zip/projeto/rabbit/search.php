<?php
	require 'include/main.php';
	check_rememberme_cookie($con);

    if (isset($_GET['q']) && !empty($_GET['q'])) {
        $search = '%' . $_GET['q'] . '%';
        $stmt = $con->prepare('SELECT id_post, posts.id_user, users.username, text, score, date FROM posts INNER JOIN users ON posts.id_user = users.id_user WHERE text LIKE ? ORDER BY score DESC, date DESC');
        $stmt->bind_param('s', $search);
        $stmt->execute();
        $stmt->store_result();
        $stmt->bind_result($id_post, $id_user, $username, $text, $score, $date);
    } else {
        header('Location: index');
        exit;
    }

    $title = 'Pesquisa: ' . $_GET['q'];
?>
<!DOCTYPE html>
<html lang="pt">
	<?php require 'include/head.php'?>
	<body>
		<?php require 'include/header.php'?>
		<main class="white">
            <?php if ($stmt->num_rows == 0) { ?>
            <div class="center">
                <div class="center-container">
                    <img src="img/rabbit.svg" alt="Logo">
                    <div class="center-box">
                        <p class="h4">Sem resultados</p>
                        <p class="caption">Pesquisa: <?=$_GET['q']?></p>
                    </div>
                    <a href="index" class="h6">Voltar à página inicial</a>
                </div>
            </div>
            <?php } else { ?>
            <div class="search-info">
                <img src="img/search.svg" alt="Search">
                <p class="infomsg">Pesquisa: <?=$_GET['q']?></p>
            </div>
            <div class="cards">
            <?php 
                while ($stmt->fetch()) {
                $date = date("d/m/Y H:i", strtotime($date));
            ?>
                <article id="post-<?=$id_post?>">
                    <div class="vote">
                        <a href="#" class="upvote">
                            <svg x="0px" y="0px" viewBox="0 0 512.171 512.171" style="enable-background:new 0 0 512.171 512.171;" xml:space="preserve" width="16px" height="16px">
                                <g>
                                    <path d="M476.723,216.64L263.305,3.115C261.299,1.109,258.59,0,255.753,0c-2.837,0-5.547,1.131-7.552,3.136L35.422,216.64    c-3.051,3.051-3.947,7.637-2.304,11.627c1.664,3.989,5.547,6.571,9.856,6.571h117.333v266.667c0,5.888,4.779,10.667,10.667,10.667    h170.667c5.888,0,10.667-4.779,10.667-10.667V234.837h116.885c4.309,0,8.192-2.603,9.856-6.592    C480.713,224.256,479.774,219.691,476.723,216.64z" data-original="#000000" class="active-path" data-old_color="#000000" fill="#cbcbcb"/>
                                </g>
                            </svg>
                        </a>
                        <p class="score caption"><?=$score?></p>
                        <a href="#" class="downvote">
                            <svg x="0px" y="0px" viewBox="0 0 512.171 512.171" style="enable-background:new 0 0 512.171 512.171;" xml:space="preserve" width="16px" height="16px">
                                <g>
                                    <path d="M479.046,283.925c-1.664-3.989-5.547-6.592-9.856-6.592H352.305V10.667C352.305,4.779,347.526,0,341.638,0H170.971    c-5.888,0-10.667,4.779-10.667,10.667v266.667H42.971c-4.309,0-8.192,2.603-9.856,6.571c-1.643,3.989-0.747,8.576,2.304,11.627    l212.8,213.504c2.005,2.005,4.715,3.136,7.552,3.136s5.547-1.131,7.552-3.115l213.419-213.504    C479.793,292.501,480.71,287.915,479.046,283.925z" data-original="#000000" class="active-path" data-old_color="#000000" fill="#cbcbcb"/>
                                </g>
                            </svg>
                        </a>
                    </div>
                    <a href="post?id=<?=$id_post?>" class="content">
                        <div class="info">
                            <div class="user-container">
                                <img src="img/user.svg" alt="User">
                                <span class="user caption"><?=$username?></span>
                            </div>
                            <div class="date-container">
                                <span class="date caption thin"> · <?=$date?></span>
                            </div>
                        </div>
                        <div class="text"><?=$text?></div>
                    </a>
                </article>
            <?php } ?>
            </div>
            <?php 
                }
                $stmt->close();
            ?>
		</main>
	</body>
</html>