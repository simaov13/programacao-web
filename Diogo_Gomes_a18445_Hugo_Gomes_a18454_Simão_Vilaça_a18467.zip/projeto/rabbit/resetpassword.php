<?php
require 'include/main.php';
$title = "Recuperação de Password";
$finished = false;
// Output message
$msg = '';
// Check if the data from the login form was submitted.
if (isset($_GET['email'], $_GET['code']) && !empty($_GET['code'])) {
    // Prepare our SQL, preparing the SQL statement will prevent SQL injection.
    $stmt = $con->prepare('SELECT * FROM users WHERE email = ? AND reset = ?');
	$stmt->bind_param('ss', $_GET['email'], $_GET['code']);
	$stmt->execute();
	$account = $stmt->fetch();
	$stmt->close();
    // If the account exists with the email and code
    if ($account) {
        if (isset($_POST['npassword'], $_POST['cpassword'])) {
            if (strlen($_POST['npassword']) > 30 || strlen($_POST['npassword']) < 8) {
            	$msg = 'A password tem de conter entre 8 e 30 caracteres!';
            } else if ($_POST['npassword'] != $_POST['cpassword']) {
                $msg = 'As passwords não coincidem!';
            } else {
                $stmt = $con->prepare('UPDATE users SET password = ?, reset = "" WHERE email = ?');
            	// We do not want to expose passwords in our database, so hash the password and use password_verify when a user logs in.
				$password = password_hash($_POST['npassword'], PASSWORD_DEFAULT);
				$stmt->bind_param('ss', $password, $_GET['email']);
				$stmt->execute();
				$stmt->close();
                $msg = 'Password alterada com sucesso!';
                $finished = true;
            }
        }
    } else {
        $msg = 'Email ou código incorreto!';
        $finished = true;
    }
} else {
    $msg = 'Nenhum código ou email especificado!';
    $finished = true;
}
?>
<!DOCTYPE html>
<html>
    <?php require 'include/head.php'?>
	<body>
		<div class="center">
            <div class="center-container">
                <a href="index"><img src="img/rabbit.svg" alt="Logo"></a>
                <div class="center-box">
                    <p class="h4">Alterar Password</p>
                    <?php if (!$finished) { ?>
                    <form action="resetpassword?email=<?=$_GET['email']?>&code=<?=$_GET['code']?>" method="POST">
                        <div class="input-container">
							<input type="password" name="npassword" placeholder="Nova Password" id="npassword" required autofocus>
						</div>
						<div class="input-container">
							<input type="password" name="cpassword" placeholder="Confirmar Password" id="cpassword" required autofocus>
                        </div>
                        <div class="alertmsg caption"><?=$msg?></div>
                        <input type="submit" value="Alterar" class="btn btn-outline caption">
                    </form>
                    <?php } else { ?>
                        <div class="alertmsg"><?=$msg?></div>
                    <?php } ?>
                </div>
                <a href="index" class="h6">Voltar à página inicial</a>
            </div>
        </div>
	</body>
</html>
