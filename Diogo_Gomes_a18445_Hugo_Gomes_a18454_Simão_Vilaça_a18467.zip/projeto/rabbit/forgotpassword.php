<?php
require 'include/main.php';
$title = "Recuperação de Password";
// Output message
$msg = '';
// Check if the data from the login form was submitted, isset() will check if the data exists.
if (isset($_POST['email'])) {
    // Prepare our SQL, preparing the SQL statement will prevent SQL injection.
	$stmt = $con->prepare('SELECT * FROM users WHERE email = ?');
	$stmt->bind_param('s', $_POST['email']);
	$stmt->execute();
	$account = $stmt->fetch();
	$stmt->close();
    // If the account exists with the email
    if ($account) {
        // Account exist, the $msg variable will be used to show the output message (on the HTML form)
        // Update the reset code in the database
        $stmt = $con->prepare('UPDATE users SET reset = ? WHERE email = ?');
		$uniqid = uniqid();
		$stmt->bind_param('ss', $uniqid, $_POST['email']);
		$stmt->execute();
		$stmt->close();
		send_recovery_email($_POST['email'], $uniqid);
        $msg = 'O link de recuperação foi enviado para o seu email!';
    } else {
        $msg = 'Não existe nenhuma conta com esse email!';
    }
}
?>
<!DOCTYPE html>
<html>
    <?php require 'include/head.php'?>
	<body>
		<div class="center">
            <div class="center-container">
                <a href="index.php"><img src="img/rabbit.svg" alt="Logo"></a>
                <div class="center-box">
                    <p class="h4">Recuperar Password</p>
                    <form action="forgotpassword.php" method="POST">
                        <div class="input-container">
                            <input type="text" name="email" placeholder="Email" id="email" required autofocus>
                        </div>
                        <div class="alertmsg caption"><?=$msg?></div>
                        <input type="submit" value="Enviar" class="btn btn-outline caption">
                    </form>
                </div>
                <a href="index.php" class="h6">Voltar à página inicial</a>
            </div>
        </div>
	</body>
</html>
