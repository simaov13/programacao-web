<?php
require 'include/main.php';
$title = "Ativação de Conta";
$msg = '';
// Check if the email and code exists, these variables will appear as parameters in the URL
if (isset($_GET['email'], $_GET['code']) && !empty($_GET['code'])) {
	$stmt = $con->prepare('SELECT * FROM users WHERE email = ? AND activation_code = ?');
	$stmt->bind_param('ss', $_GET['email'], $_GET['code']);
	$stmt->execute();
	// Store the result so we can check if the account exists in the database.
	$stmt->store_result();
	if ($stmt->num_rows > 0) {
		$stmt->close();
		// Account exists with the requested email and code.
		$stmt = $con->prepare('UPDATE users SET activation_code = ? WHERE email = ? AND activation_code = ?');
		// Set the new activation code to 'activated', this is how we can check if the user has activated their account.
		$newcode = 'activated';
		$stmt->bind_param('sss', $newcode, $_GET['email'], $_GET['code']);
		$stmt->execute();
		$stmt->close();
		$msg = 'A sua conta está agora ativada!';
	} else {
		$msg = 'A conta já está ativada ou não existe!';
	}
} else {
	$msg = 'Nenhum código ou email especificado!';
}
?>
<!DOCTYPE html>
<html>
	<?php require 'include/head.php'?>
	<body>
		<div class="center">
			<div class="center-container">
				<a href="index.php"><img src="img/rabbit.svg" alt="Logo"></a>
				<div class="center-box">
					<p class="h4"><?=$msg?></p>
				</div>
				<a href="index" class="h6">Voltar à página inicial</a>
			</div>
		</div>
	</body>
</html>
