<?php
	require 'include/main.php';
	check_rememberme_cookie($con);

    if (isset($_GET['u']) && !empty($_GET['u'])) {
        $stmt = $con->prepare('SELECT id_user, username, email, since FROM users WHERE username = ?');
        $stmt->bind_param('s', $_GET['u']);
        $stmt->execute();
        $stmt->store_result();
        $stmt->bind_result($id_user, $username, $email, $since);
        $stmt->fetch();

        $since = strftime('%d de %B de %Y', strtotime($since));
    } else {
        header('Location: index');
        exit;
    }

    if ($stmt->num_rows != 0) {
        $title = 'Perfil: ' . $_GET['u'];
        $exists = true;
    } else {
        $title = 'Perfil inexistente';
        $exists = false;
    }

    $stmt->close();
?>

<!DOCTYPE html>
<html lang="pt">
	<?php require 'include/head.php'?>
	<body>
		<?php require 'include/header.php'?>
		<main class="white">
            <?php if (!$exists) { ?>
            <div class="center">
                <div class="center-container">
                    <img src="img/rabbit.svg" alt="Logo">
                    <div class="center-box">
                        <p class="h4">Perfil inexistente</p>
                    </div>
                    <a href="index" class="h6">Voltar à página inicial</a>
                </div>
            </div>
            <?php } else { ?>
            <div class="infomsg">Perfil</div>
            <div class="profile-info">
                <div class="profile-info-container">
                    <img src="img/user.svg" alt="<?=$username?>">
                </div>
                <div class="profile-info-container">
                    <p class="profile-name"><?=$username?></p>
                    <p class="caption light">Registado desde <?=$since?></p>
                </div>
            </div>
            <?php require 'include/userposts.php'; } ?>
		</main>
	</body>
</html>