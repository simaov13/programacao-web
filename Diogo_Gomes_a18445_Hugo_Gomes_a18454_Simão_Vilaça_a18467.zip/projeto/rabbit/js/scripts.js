$(document).ready(function () {
	$(".login").on("click", function (e) {
		e.preventDefault();
		$(".signin").removeClass("hidden");
		$("#signin-username").focus();
	});

	$(".register").on("click", function (e) {
		e.preventDefault();
		$(".signup").removeClass("hidden");
		$("#signup-username").focus();
	});

	$(".close").on("click", function (e) {
		e.preventDefault();
		$(".modal").addClass("hidden");
	});

	$(".loginnow").on("click", function (e) {
		e.preventDefault();
		$(".signin").removeClass("hidden");
		$(".signup").addClass("hidden");
		$("#signin-username").focus();
	});

	$(".registernow").on("click", function (e) {
		e.preventDefault();
		$(".signup").removeClass("hidden");
		$(".signin").addClass("hidden");
		$("#signup-username").focus();
	});

	$(".signin form").on("submit", function (e) {
		e.preventDefault();
		$("#signin-submit").prop("disabled", true);
		$("#signin-submit").val("Por favor, agurade...");

		let form = document.querySelector(".signin form");
		let form_data = new FormData(form);
		let xhr = new XMLHttpRequest();
		xhr.open("POST", form.action, true);
		xhr.onload = function () {
			$("#signin-submit").prop("disabled", false);
			$("#signin-submit").val("Entrar");

			if (this.responseText == "Success") {
				window.location.href = "index.php";
			} else {
				document.querySelector(".msgsignin").innerHTML = this.responseText;
			}
		};
		xhr.send(form_data);
	});

	$(".signup form").on("submit", function (e) {
		e.preventDefault();
		$("#signup-submit").prop("disabled", true);
		$("#signup-submit").val("Por favor, agurade...");

		let form = document.querySelector(".signup form");
		let form_data = new FormData(form);
		let xhr = new XMLHttpRequest();
		xhr.open("POST", form.action, true);
		xhr.onload = function () {
			document.querySelector(".msgsignup").innerHTML = this.responseText;
			$("#signup-submit").prop("disabled", false);
			$("#signup-submit").val("Registar");
		};
		xhr.send(form_data);
	});

	$(".search-icon").on("click", function (e) {
		e.preventDefault();
		$(".search-form").submit();
	});

	$(".edit-confirm").on("click", function (e) {
		e.preventDefault();
		$(".edit-form").submit();
	});
});
