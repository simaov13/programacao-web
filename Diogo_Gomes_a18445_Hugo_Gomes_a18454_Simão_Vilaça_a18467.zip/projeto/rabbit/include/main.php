<?php
// The main file contains the database connection, session initializing, and functions, other PHP files will depend on this file.
// Include the configuration file
require_once 'include/config.php';

// We need to use sessions, so you should always start sessions using the below function
session_start();

// Connect to the MySQL database using MySQLi
$con = mysqli_connect(db_host, db_user, db_pass, db_name);
if (mysqli_connect_errno()) {
	exit('Failed to connect to MySQL: ' . mysqli_connect_error());
}

// Update the charset
mysqli_set_charset($con, db_charset);

// Update the locale
setlocale(LC_TIME, 'portuguese_Portugal');

// Check the remember me cookie
function check_rememberme_cookie($con) {
	// Check if the user is "remembered"
	if (isset($_COOKIE['rememberme']) && !empty($_COOKIE['rememberme'])) {
		// If the remember me cookie matches one in the database then update the session variables.
		$stmt = $con->prepare('SELECT id_user, username FROM users WHERE rememberme = ?');
		$stmt->bind_param('s', $_COOKIE['rememberme']);
		$stmt->execute();
		$stmt->store_result();
		if ($stmt->num_rows > 0) {
			// Found a match
			$stmt->bind_result($id, $username);
			$stmt->fetch();
			$stmt->close();
			session_regenerate_id();
			$_SESSION['loggedin'] = TRUE;
			$_SESSION['name'] = $username;
			$_SESSION['id'] = $id;
		}
	}
}

// Send activation email function
function send_activation_email($email, $code) {
	$subject = 'Ativação de Conta';
	$headers = 'From: ' . mail_from . "\r\n" . 'Reply-To: ' . mail_from . "\r\n" . 'Return-Path: ' . mail_from . "\r\n" . 'X-Mailer: PHP/' . phpversion() . "\r\n" . 'MIME-Version: 1.0' . "\r\n" . 'Content-Type: text/html; charset=UTF-8' . "\r\n";
	$activate_link = activation_link . '?email=' . $email . '&code=' . $code;
	$email_template = str_replace('%link%', $activate_link, file_get_contents('email/activation-email-template.html'));
	mail($email, $subject, $email_template, $headers);
}

// Send recovery email function
function send_recovery_email($email, $code) {
	$subject = 'Recuperação de Password';
	$headers = 'From: ' . mail_from . "\r\n" . 'Reply-To: ' . mail_from . "\r\n" . 'Return-Path: ' . mail_from . "\r\n" . 'X-Mailer: PHP/' . phpversion() . "\r\n" . 'MIME-Version: 1.0' . "\r\n" . 'Content-Type: text/html; charset=UTF-8' . "\r\n";
	$activate_link = recovery_link . '?email=' . $email . '&code=' . $code;
	$email_template = str_replace('%link%', $activate_link, file_get_contents('email/recovery-email-template.html'));
	mail($email, $subject, $email_template, $headers);
}
?>