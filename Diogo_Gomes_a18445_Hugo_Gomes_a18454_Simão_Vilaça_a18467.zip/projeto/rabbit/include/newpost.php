<?php
    if (isset($_POST['newpost']) && !empty($_POST['newpost'])) {
        $stmt = $con->prepare('INSERT INTO posts (id_user, text) VALUES (?, ?)');
        $stmt->bind_param('is', $_SESSION['id'], $_POST['newpost']);
        $stmt->execute();
        $id_post = $stmt->insert_id;
        $stmt->close();
        
        header('Location: post?id=' . $id_post);
        exit;
    }
?>

<div class="newpost">
    <?php if (isset($_SESSION['loggedin'])) { ?>
    <form action="index" method="POST">
        <label for="newpost" class="infomsg">Novo Post</label>
        <textarea name="newpost" required></textarea>
        <div class="input-wrapper">
            <input type="submit" value="Postar" class="btn btn-outline">
        </div>
    </form>
    <?php } else { ?>
    <div class="infomsg-box">
        <p class="infomsg"><a href="#" class="login">Entre</a> ou <a href="#" class="register">registe-se</a> para criar um post.</p>
    </div>
    <?php } ?>
</div>