<?php
// database hostname
define('db_host', 'localhost');
// database username
define('db_user', 'root');
// database password
define('db_pass', '');
// database name
define('db_name', 'rabbit');
// database charset
define('db_charset', 'utf8');
// Email activation variables
// Account activation required?
define('account_activation', true);
// Mail from
define('mail_from', 'Rabbit <rabbitforum@outlook.com>');
// Link to activation file
define('activation_link', 'http://localhost/rabbit/activate.php');
// Link to recovery file
define('recovery_link', 'http://localhost/rabbit/resetpassword.php');
// php.ini mail function
ini_set('SMTP', 'smtp-mail.outlook.com');
ini_set('smtp_port', '587');
ini_set('sendmail_from', 'rabbitforum@outlook.com');
ini_set('sendmail_path', '\"C:\xampp\sendmail\sendmail.exe\" -t');
?>
