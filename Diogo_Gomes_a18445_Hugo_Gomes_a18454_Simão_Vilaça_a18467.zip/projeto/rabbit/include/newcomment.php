<div class="newcomment">
    <?php if (isset($_SESSION['loggedin'])) { ?>
    <form action="post?id=<?=$_GET['id']?>" method="POST">
        <label for="newcomment" class="infomsg">Escrever Comentário</label>
        <textarea name="newcomment" required></textarea>
        <div class="input-wrapper">
            <input type="submit" value="Comentar" class="btn btn-outline">
        </div>
    </form>
    <?php } else { ?>
    <div class="infomsg-box">
        <p class="infomsg"><a href="#" class="login">Entre</a> ou <a href="#" class="register">registe-se</a> para escrever um comentário.</p>
    </div>
    <?php } ?>
</div>