<header>
	<div class="header-container">
		<a href="index" class="logo">
			<img src="img/rabbit.svg" alt="Logo">
			<span class="h4">rabbit</span>
		</a>
		<div class="search">
			<form action="search" method="GET" class="search-form">
				<a href="#" class="search-icon"><img src="img/search.svg" alt="Search"></a>
				<input type="text" name="q" placeholder="Pesquisar">
			</form>
		</div>
		<div class="session">
			<?php if (!isset($_SESSION['loggedin'])) { ?>
			<a href="#" class="login btn btn-outline">Entrar</a>
			<a href="#" class="register btn btn-fill">Registar</a>
			<?php } else { ?>
				<a href="profile?u=<?=$_SESSION['name']?>" class="profile btn btn-outline"><?=$_SESSION['name']?></a>
				<a href="logout" class="logout btn btn-fill">Sair</a>
			<?php } ?>
		</div>
	</div>
	<?php if (!isset($_SESSION['loggedin'])) { ?>
	<div class="signin modal hidden">
		<div class="signin-container modal-container">
			<a href="#" class="close"><img src="img/close.svg" alt="Close"></a>
			<h3 class="title">Entrar</h3>
			<form action="authenticate.php" method="POST" autocomplete="off">
				<div class="input-container">
					<label for="username" class="caption">Utilizador</label>
					<input type="text" name="username" id="signin-username">
				</div>
				<div class="input-container">
					<label for="password" class="caption">Password</label>
					<input type="password" name="password" id="signin-password">
				</div>
				<div class="checkbox-container">
					<input type="checkbox" name="rememberme" id="rememberme">
					<label for="rememberme">Manter sessão iniciada</label>
				</div>
				<div class="submit-container">
					<input type="submit" value="Entrar" class="btn btn-fill" id="signin-submit">
					<div class="alertmsg msgsignin"></div>
				</div>
			</form>
			<a href="forgotpassword">Esqueceu-se da password?</a>
			<p>Não tem uma conta? <a href="#" class="registernow">Registe-se já!</a></p>
		</div>
	</div>
	<div class="signup modal hidden">
		<div class="signup-container modal-container">
			<a href="#" class="close"><img src="img/close.svg" alt="Close"></a>
			<h3 class="title">Registar</h3>
			<form action="register.php" method="POST" autocomplete="off">
				<div class="input-group">
					<div class="input-container">
						<label for="username" class="caption">Utilizador</label>
						<input type="text" name="username" id="signup-username">
					</div>
					<div class="input-container">
						<label for="email" class="caption">Email</label>
						<input type="text" name="email" id="signup-email">
					</div>
				</div>
				<div class="input-group">
					<div class="input-container">
						<label for="password" class="caption">Password</label>
						<input type="password" name="password" id="signup-password">
					</div>
					<div class="input-container">
						<label for="cpassword" class="caption">Confirmar Password</label>
						<input type="password" name="cpassword" id="signup-cpassword">
					</div>
				</div>
				<div class="submit-container">
					<input type="submit" value="Registar" class="btn btn-fill" id="signup-submit">
					<div class="alertmsg msgsignup"></div>
				</div>
			</form>
			<p>Já tem uma conta? <a href="#" class="loginnow">Entre agora!</a></p>
		</div>
	</div>
	<?php } ?>
</header>
