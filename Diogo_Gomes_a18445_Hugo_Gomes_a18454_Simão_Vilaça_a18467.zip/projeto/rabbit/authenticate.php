<?php
require 'include/main.php';
// Check if the data from the login form was submitted.
if (!isset($_POST['username'], $_POST['password']) || empty($_POST['username']) || empty($_POST['password'])) {
	// Could not get the data that should have been sent.
	exit('Preencha todos os campos!');
}
// Prepare our SQL, preparing the SQL statement will prevent SQL injection.
$stmt = $con->prepare('SELECT id_user, password, rememberme, activation_code FROM users WHERE username = ?');
// Bind parameters
$stmt->bind_param('s', $_POST['username']);
$stmt->execute();
// Store the result so we can check if the account exists in the database.
$stmt->store_result();
// Check if the account exists:
if ($stmt->num_rows > 0) {
	$stmt->bind_result($id, $password, $rememberme, $activation_code);
	$stmt->fetch();
	$stmt->close();
	// Account exists, verify the password.
	if (password_verify($_POST['password'], $password)) {
		// Check if the account is activated
		if (account_activation && $activation_code != 'activated') {
			// User has not activated the account, output the message
			echo 'Ative a sua conta para entrar, clique <a href="resendactivation.php">aqui</a> para reenviar o email de ativação!';
		} else {
			// Verification success! User has loggedin!
			// Create sessions so we know the user is logged in, they basically act like cookies but remember the data on the server.
			session_regenerate_id();
			$_SESSION['loggedin'] = TRUE;
			$_SESSION['name'] = $_POST['username'];
			$_SESSION['id'] = $id;
			// If the user checked the remember me check box:
			if (isset($_POST['rememberme'])) {
				// Create a hash that will be stored as a cookie and in the database, this will be used to identify the user.
				$cookiehash = !empty($rememberme) ? $rememberme : password_hash($id . $_POST['username'] . 'yoursecretkey', PASSWORD_DEFAULT);
				// The amount of days a user will be remembered:
				$days = 30;
				setcookie('rememberme', $cookiehash, (int)(time()+60*60*24*$days));
				// Update the "rememberme" field in the users table
				$stmt = $con->prepare('UPDATE users SET rememberme = ? WHERE id_user = ?');
				$stmt->bind_param('si', $cookiehash, $id);
				$stmt->execute();
				$stmt->close();
			}
			echo 'Success'; // This will be used to check with the AJAX code
		}
	} else {
		echo 'Password incorreta!';
	}
} else {
	echo 'Utilizador inválido!';
}
?>
