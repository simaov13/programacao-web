<?php
	require 'include/main.php';
	check_rememberme_cookie($con);
	$title = "rabbit: qualquer semelhança é mera coincidência...";
?>
<!DOCTYPE html>
<html lang="pt">
	<?php require 'include/head.php'?>
	<body>
		<?php require 'include/header.php'?>
		<main class="white">
			<section class="posts">
				<?php require 'include/newpost.php'?>
				<?php require 'include/posts.php'?>
			</section>
		</main>
	</body>
</html>
