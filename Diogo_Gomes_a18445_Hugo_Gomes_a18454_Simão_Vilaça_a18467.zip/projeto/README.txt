Instalação:

- Colocar a pasta rabbit na root (xampp/htdocs).
	Caso pretenda modificar o caminho, também terá de o fazer em ambos os links no ficheiro config.php visto que estes são os links que vão nos emails de ativação e recuperação.

- Importar a base de dados (rabbit.sql) para o phpMyAdmin e de preferência deixar o nome predefinido (rabbit).
	Caso pretenda modificar o nome da base de dados, também terá de o fazer no ficheiro config.php no devido local.
	
- Substituir os ficheiros php.ini (xampp/php/php.ini) e sendmail.ini (xampp/sendmail/sendmail.ini) pelos que se encontram aqui com a devida configuração para que seja possível enviar emails de ativação e recuperação.
	Caso pretenda alterar as configurações nos seus próprios ficheiros, consulte a imagem que aqui se encontra (phpsendmailconfig.png) e coloque tudo exatamente como se encontra na imagem.
	Em último recurso, é possível desligar a ativação por email no ficheiro config.php (account_activation -> false)



Observações:

- Alguns clientes de email demoram cerca de 5 minutos a mostrar o email na caixa de entrada no primeiro email que é enviado para um determinado endereço de email ou então marcam o email como SPAM.

- Todas as contas que se encontram atualmente na base de dados, que foram utilizadas para fazer testes, têm a password igual ao username.

- Para além do que era pedido, foram implementadas as seguintes funcionalidades:
	- Ativação de conta por email;
	- Recuperação de password por email;
	- Página de perfil de cada utilizador;

- Daquilo que foi pedido, apenas não foi implementado o sistema de votação mas os posts encontram-se na mesma ordenados por pontuação (alterar manualmente na base de dados a coluna score para verificar).