<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ex2</title>
</head>
<body>
    <form action="bmi_result.php" method="GET">

        <label for="number">Altura: </label>
		<input type="number" name="altura">

        <br><br>

        <label for="number">Peso: </label>
		<input type="number" name="peso">
        
        <button type="submit">Calcular!</button>
    </form>
</body>
</html>